"""Reproducible RDM Confluence icon assets. Requires Pillow; no fonts/network needed."""
from pathlib import Path
import re
import zipfile
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent
SIZES = (16, 20, 24, 32, 48, 64, 96, 128, 256, 512, 1024)
TILE = 'M 64 8 L 192 8 Q 248 8 248 64 L 248 192 Q 248 248 192 248 L 64 248 Q 8 248 8 192 L 8 64 Q 8 8 64 8 Z'
ARROW = 'M 118 48 L 138 48 Q 144 48 144 54 L 144 118 L 156 118 L 156 76 Q 156 70 162 70 L 176 70 Q 182 70 182 76 L 182 126 L 192 126 Q 197 126 193 131 L 134 188 Q 128 194 122 188 L 63 131 Q 59 126 64 126 L 74 126 L 74 76 Q 74 70 80 70 L 94 70 Q 100 70 100 76 L 100 118 L 112 118 L 112 54 Q 112 48 118 48 Z'
TRAY = 'M 61 183 Q 61 179 65 179 L 71 179 Q 75 179 75 183 L 75 201 Q 75 205 79 205 L 177 205 Q 181 205 181 201 L 181 183 Q 181 179 185 179 L 191 179 Q 195 179 195 183 L 195 203 Q 195 219 179 219 L 77 219 Q 61 219 61 203 Z'
FACET = 'M 128 145 L 193 128 L 134 188 Q 128 194 122 188 L 63 131 Z'
HIGHLIGHT = 'M 119 54 L 123 54 L 123 122 L 119 122 Z'


def points(path):
    tokens = re.findall(r'[MLQZ]|-?\d+(?:\.\d+)?', path)
    out, i, current = [], 0, (0, 0)
    while i < len(tokens):
        op = tokens[i]; i += 1
        if op == 'Z':
            break
        count = 4 if op == 'Q' else 2
        nums = list(map(float, tokens[i:i+count])); i += count
        if op == 'Q':
            a = current; b = nums[:2]; c = nums[2:]
            for j in range(1, 25):
                t = j / 24
                out.append(((1-t)**2*a[0]+2*(1-t)*t*b[0]+t*t*c[0], (1-t)**2*a[1]+2*(1-t)*t*b[1]+t*t*c[1]))
            current = tuple(c)
        else:
            current = tuple(nums); out.append(current)
    return out


def gradient(n, top, bottom):
    im = Image.new('RGBA', (1, n))
    for y in range(n):
        t = y/(n-1)
        im.putpixel((0,y), tuple(round(a+(b-a)*t) for a,b in zip(top,bottom)) + (255,))
    return im.resize((n,n))


def render(size, bare=False, mono=False):
    n = max(1024, size * 2)
    canvas = Image.new('RGBA', (n,n))
    def layer(path, top, bottom=None, alpha=255):
        mask = Image.new('L', (n,n))
        ImageDraw.Draw(mask).polygon([(x*n/256,y*n/256) for x,y in points(path)], fill=alpha)
        fill = gradient(n, top, bottom or top)
        canvas.alpha_composite(Image.composite(fill, Image.new('RGBA',(n,n)), mask))
    if not bare:
        layer(TILE, (28,49,81), (8,17,35))
    if mono:
        layer(ARROW,(255,255,255)); layer(TRAY,(255,255,255))
    else:
        layer(ARROW,(159,225,255),(27,206,193))
        if size >= 32:
            layer(FACET,(24,141,219),(19,179,185),100)
        if size >= 64:
            layer(HIGHLIGHT,(224,248,255),alpha=110)
        layer(TRAY,(67,167,244),(32,206,210))
    result = canvas.resize((size,size),Image.Resampling.LANCZOS)
    result.putalpha(result.getchannel('A').point(lambda a: 0 if a < 4 else a))
    return result


def svg(bare=False, mono=False, small=False):
    defs = '<defs><linearGradient id="tile" x2="0" y2="1"><stop stop-color="#1c3151"/><stop offset="1" stop-color="#081123"/></linearGradient><linearGradient id="arrow" x2="0" y2="1"><stop stop-color="#9fe1ff"/><stop offset="1" stop-color="#1bcec1"/></linearGradient><linearGradient id="tray" x2="0" y2="1"><stop stop-color="#43a7f4"/><stop offset="1" stop-color="#20ced2"/></linearGradient></defs>'
    # userSpaceOnUse makes SVG and raster gradients share the full canvas coordinate system.
    defs = defs.replace('x2="0" y2="1"', 'gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="256"')
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256" role="img" aria-label="RDM Confluence download icon"><title>RDM — Confluence Download</title>',defs]
    def path(d,fill,extra=''):
        parts.append(f'<path d="{d}" fill="{fill}" {extra}/>')
    if not bare: path(TILE,'url(#tile)')
    path(ARROW,'#ffffff' if mono else 'url(#arrow)')
    if not mono and not small:
        # Full-canvas interpolated facet gradient, matching raster rendering.
        parts.append('<defs><linearGradient id="facet" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="256"><stop stop-color="#188ddb"/><stop offset="1" stop-color="#13b3b9"/></linearGradient></defs>')
        path(FACET,'url(#facet)','opacity="0.392157"')
        path(HIGHLIGHT,'#e0f8ff','opacity="0.431373"')
    path(TRAY,'#ffffff' if mono else 'url(#tray)')
    return ''.join(parts)+'</svg>\n'


def main():
    for name, opts in [('rdm.svg',{}),('rdm-small.svg',{'small':True}),('rdm-mark.svg',{'bare':True}),('rdm-monochrome.svg',{'bare':True,'mono':True})]:
        (OUT/name).write_text(svg(**opts),encoding='utf-8')
    for size in SIZES:
        render(size).save(OUT/f'rdm-{size}.png',optimize=True)
    render(1024,bare=True).save(OUT/'rdm-mark-1024.png',optimize=True)
    render(1024,bare=True,mono=True).save(OUT/'rdm-monochrome-1024.png',optimize=True)
    ico_sizes = (16,24,32,48,64,128,256)
    images = [render(s) for s in ico_sizes]
    images[-1].save(OUT/'rdm.ico',format='ICO',sizes=[(s,s) for s in ico_sizes],append_images=images[:-1])
    preview = Image.new('RGB',(1200,760),'#edf1f7')
    d=ImageDraw.Draw(preview)
    d.text((48,30),'RDM / CONFLUENCE DOWNLOAD',fill='#13243b',font_size=28)
    preview.paste(render(440),(60,105),render(440))
    d.rounded_rectangle((560,105,1150,545),radius=24,fill='#0c1526')
    mark=render(340,bare=True)
    preview.paste(mark,(685,150),mark)
    d.text((70,565),'APP ICON',fill='#44546a',font_size=18)
    d.text((580,565),'TRANSPARENT SYMBOL',fill='#44546a',font_size=18)
    x=70
    for s in (16,24,32,48,64,96):
        im=render(s); preview.paste(im,(x,620+(96-s)//2),im)
        d.text((x,724),str(s)+' px',fill='#44546a',font_size=14)
        x+=165
    preview.save(OUT/'preview.png',optimize=True)
    for s in SIZES:
        with Image.open(OUT/f'rdm-{s}.png') as im:
            assert im.size == (s,s) and im.mode == 'RGBA'
            assert im.getpixel((0,0))[3] == 0
    with Image.open(OUT/'rdm.ico') as im:
        assert im.ico.sizes() == {(s,s) for s in ico_sizes}
        for s in ico_sizes:
            assert im.ico.getimage((s,s)).size == (s,s)
    with zipfile.ZipFile(OUT/'rdm-confluence-assets.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(OUT.iterdir()):
            if p.suffix in ('.svg','.png','.ico','.py','.md'):
                archive.write(p,p.name)
    print('Generated and validated 11 PNG sizes, transparent marks, 4 SVGs, 7-frame ICO, preview and ZIP.')

if __name__ == '__main__':
    main()
