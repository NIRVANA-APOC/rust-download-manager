# RDM · 汇流下载图标

根据已确认的「汇流下载」概念方向重新绘制的可复现矢量版本，不是生成式概念图的逐像素复刻。三条竖向数据流汇入向下箭头，底部为接收托盘；深海军蓝底配冰蓝—青绿渐变。

## 素材

- [rdm.svg](rdm.svg)：完整应用图标，圆角底板外透明。
- [rdm-small.svg](rdm-small.svg)：无细小高光及切面的简化版本。
- [rdm-mark.svg](rdm-mark.svg)：无底板彩色标记，透明背景。
- [rdm-monochrome.svg](rdm-monochrome.svg)：白色单色标记，供深色底使用。
- PNG：16、20、24、32、48、64、96、128、256、512、1024px；16–24px 无高光/切面，32–48px 保留切面但无细高光。
- [rdm-mark-1024.png](rdm-mark-1024.png)：透明底彩色标记。
- [rdm-monochrome-1024.png](rdm-monochrome-1024.png)：透明底白色标记。
- [rdm.ico](rdm.ico)：16、24、32、48、64、128、256px 内嵌图层。
- [preview.png](preview.png)：浅色/深色底及原尺寸缩略图预览。
- [rdm-confluence-assets.zip](rdm-confluence-assets.zip)：完整素材包，含生成脚本。

## 再生成

使用 Python 3 + Pillow：

```powershell
python assets/branding/confluence/generate.py
```

生成器会检查 PNG 的尺寸、RGBA 模式、透明角落和 ICO 的全部尺寸层。SVG 为无外部依赖的路径与渐变；PNG 使用同源几何绘制，不依赖 SVG 转换器，抗锯齿效果可能与浏览器略有不同。

## 接入状态

素材独立存放，尚未覆盖 Firefox 扩展的现有图标，也未修改桌面端构建或嵌入资源。确认最终外观后，可将所需 PNG 放入扩展资源目录，将 ICO 接入 Windows 资源编译。
